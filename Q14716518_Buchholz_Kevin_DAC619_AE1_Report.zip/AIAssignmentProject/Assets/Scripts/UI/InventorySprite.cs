﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// The sprite representing an inventory item
/// </summary>
public class InventorySprite : MonoBehaviour
{
    public Sprite UiSprite;
}
